# analisis_electoral_2023_arg
Gráfico comparativo entre las PASO 2023 y las elecciones generales 2023 para los tres partidos principales. Shiny app disponible en:
https://rquiroga7.shinyapps.io/Elecciones_2023/
. Queda pendiente modificar el código para incorporar al FIT y a Hacemos por Nuestro País.

Así se observa la app:
![image](https://github.com/rquiroga7/analisis_electoral_2023_arg/assets/8103453/39400495-912e-4c6d-93ec-959c0b82741b)

La línea naranja indica donde deberían caer las mesas si todo el aumento de participación resultara en un aumento de votos para esta fuerza. Si las mesas se encuentran por arriba de esta línea, sugiere transferencia de votos de otras fuerzas a ésta, y por debajo indica lo contrario. Se provee una checkbox para filtrar las mesas con participación menor a 50 en PASO o generales. Como los datos son provisorios, puede haber errores de carga de telegramas.
